Archivos basicos de SQL
SQL Server Transact SQL
Oracle PL SQL
